 <?php
$servername = "localhost";
$username = "root";
$password = "toor";
$database = "dragdrop";


// Check connection
$conn = new mysqli($servername, $username, $password, $database);
 
if($db->connect_errno > 0){
    die('Unable to connect to database [' . $db->connect_error . ']');
}
//print_r($conn); die;
    // MySQL table's name
$tableName = 'chats';
// Get JSON file and decode contents into PHP arrays/values
$jsonFile = 'chat-messages.json';
$jsonData = json_decode(file_get_contents($jsonFile), true);
//print_r($jsonData); die;
// Iterate through JSON and build INSERT statements
foreach ($jsonData as $id=>$row) {
    $insertPairs = array();
    foreach ($row as $key=>$val) {
    	foreach($val as $k=>$vl){

        $insertPairs[addslashes($k)] = addslashes($vl);
    	}

    $insertKeys = '`' . implode('`,`', array_keys($insertPairs)) . '`';
    $insertVals = '"' . implode('","', array_values($insertPairs)) . '"';
    echo "INSERT INTO `{$tableName}` ({$insertKeys}) VALUES ({$insertVals});" . "<hr/>";
    }
    //print_r($insertPairs); die;

}
die;
$sql = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


echo "Connected successfully";
?> 